//
//  WaveformViewerTests.h
//  WaveformViewerTests
//
//  Created by Daniel Schmidt on 04.02.13.
//  Copyright (c) 2013 Daniel Schmidt. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface WaveformViewerTests : SenTestCase

@end
